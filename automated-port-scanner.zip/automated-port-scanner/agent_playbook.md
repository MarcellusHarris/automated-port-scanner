# Agent Playbook for Automated Port Scanner & VA

1. **Implement features:** Verify that the scanner supports the `--json` flag and writes structured output. Add a `--dry-run` flag if not present.
2. **Example outputs:** Run the scanner against a test host and update `examples/scan.json` and `examples/scan.txt` to reflect the current output format.
3. **Performance tuning:** Test the `--max-rate` option to ensure it respects rate limits and document reasonable default values.
4. **Safety:** Review the README’s safety section periodically and ensure legal considerations are clearly stated.
5. **Issues:** Open issues for any missing functionality, such as service detection improvements or CVE database integrations.
