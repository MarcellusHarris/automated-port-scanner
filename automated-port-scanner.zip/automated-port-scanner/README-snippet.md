## Automated Port Scanner & Vulnerability Assessment

This utility enumerates open ports on specified targets, identifies running services and known vulnerabilities, and can emit JSON or human‑readable text. A new `--json` flag outputs machine‑readable results for integration with other tools.

### Quick Start

Run the scanner against one or more IP addresses or hostnames:

```bash
python scan.py --targets 192.0.2.1 203.0.113.5 --max-rate 1000 --json --output scan.json
```

Use the `--max-rate` flag to control the number of probes per second; lower values reduce network impact. When `--json` is omitted, a formatted text report is written instead. See the `examples/` folder for sample `scan.json` and `scan.txt` outputs.

### Safety & scope

Always obtain permission before performing scans. Limit the scope to hosts you own or are authorised to assess. Use conservative `--max-rate` settings to avoid overwhelming network devices. Consider adding a `--dry-run` option to preview what would be scanned without sending any packets.
