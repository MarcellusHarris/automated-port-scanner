### Automated Port Scanner & VA TODOs

To complete this project for Agent Mode:

- [ ] **JSON output:** Implement and document a `--json` flag that writes structured results to a file.
- [ ] **Example outputs:** Add `/examples/scan.json` and `/examples/scan.txt` showing typical results.
- [ ] **README updates:** Document the `--max-rate` option and include a safety note about scanning only authorised systems.
- [ ] **Scope disclaimer:** Add a section describing proper usage, legal considerations, and a potential `--dry-run` mode.
